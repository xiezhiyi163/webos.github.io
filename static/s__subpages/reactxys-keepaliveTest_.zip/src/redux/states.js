var states = {
	test:300
}

export default states