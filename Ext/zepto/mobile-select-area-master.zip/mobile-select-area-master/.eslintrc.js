{
    "plugins": [
        "react"
    ],
    "env": {
        "jquery": true,
        "require": true
    },
    "rules": {
        "indent": ["error", 4]
    }
}